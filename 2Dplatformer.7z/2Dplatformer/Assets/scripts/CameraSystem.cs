﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

	

public class CameraSystem : MonoBehaviour {

	private GameObject player;
	public float xmin = -10.5f;
	public float xmax = 1000f;
	public float ymin;
	public float ymax;

	// Use this for initialization
	void Start () {

		player = GameObject.FindGameObjectWithTag ("Player");
		
	}
	
	// LateUpdate is called at end of update cycle
	void LateUpdate () {
		float x = Mathf.Clamp (player.transform.position.x, xmin, xmax);
		float y = Mathf.Clamp (player.transform.position.y, ymin, ymax);
		gameObject.transform.position = new Vector3 (x, y, gameObject.transform.position.z);
		
	}
}
